const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bcrypt = require("bcrypt");
const QRCode = require("qrcode");
const { v4: uuidv4 } = require("uuid");

const app = express();

app.use(express.json());
app.use(cors());

const db = mysql.createConnection({
host:"localhost",
user:"root",
password:"Root",
database:"scan"
});

db.connect(err=>{
if(err) throw err;
console.log("MySQL connected");
});


/* REGISTER */

app.post("/register",async(req,res)=>{

const {email,password}=req.body;

const hashed=await bcrypt.hash(password,10);

const sql="INSERT INTO users(email,password) VALUES(?,?)";

db.query(sql,[email,hashed],(err,result)=>{

if(err) return res.status(500).send(err);

res.json({
userId:result.insertId
});

});

});


/* GENERATE QR */

app.get("/generate-qr/:userId",async(req,res)=>{

const userId=req.params.userId;

const token=uuidv4();

const sql="INSERT INTO qr_sessions(token,status,user_id) VALUES(?,?,?)";

db.query(sql,[token,"PENDING",userId],async err=>{

if(err) return res.status(500).send(err);

const url=`https://stunning-kataifi-7d41ab.netlify.app/?token=${token}`;

const qr=await QRCode.toDataURL(url);

res.json({
qr,
token
});

});

});


/* APPROVE LOGIN */

app.post("/approve",(req,res)=>{

const {token}=req.body;

const sql="UPDATE qr_sessions SET status='APPROVED' WHERE token=?";

db.query(sql,[token],err=>{

if(err) return res.status(500).send(err);

res.json({message:"Approved"});

});

});


/* CHECK STATUS */

app.get("/status/:token",(req,res)=>{

const token=req.params.token;

const sql="SELECT * FROM qr_sessions WHERE token=?";

db.query(sql,[token],(err,result)=>{

if(err) return res.status(500).send(err);

res.json(result[0]);

});

});

app.listen(5000,()=>{
console.log("Server running on port 5000");
});